const express = require("express");
const session = require("express-session");
const passport = require("passport");
const DiscordStrategy = require("passport-discord").Strategy;
const dotenv = require("dotenv");
const path = require("path");

dotenv.config();

const app = express();
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.static("public"));

app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());

passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((obj, done) => done(null, obj));

passport.use(new DiscordStrategy({
  clientID: process.env.CLIENT_ID,
  clientSecret: process.env.CLIENT_SECRET,
  callbackURL: process.env.CALLBACK_URL,
  scope: ['identify', 'guilds']
}, (accessToken, refreshToken, profile, done) => {
  process.nextTick(() => done(null, profile));
}));

// الصفحة الرئيسية
app.get("/", (req, res) => {
  res.render("index", { user: req.user });
});

// تسجيل الدخول
app.get("/auth/discord", passport.authenticate("discord"));
app.get("/auth/discord/callback",
  passport.authenticate("discord", { failureRedirect: "/" }),
  (req, res) => res.redirect("/dashboard")
);

// تسجيل الخروج
app.get("/logout", (req, res) => {
  req.logout(err => {
    if (err) return res.send("خطأ أثناء تسجيل الخروج");
    res.redirect("/");
  });
});

// لوحة التحكم
app.get("/dashboard", (req, res) => {
  if (!req.isAuthenticated() || !req.user) return res.redirect("/");
  const guilds = req.user.guilds.filter(guild =>
    (guild.permissions & 0x20) === 0x20 // Manage Guild
  );
  res.render("dashboard", { user: req.user, guilds });
});

// تشغيل السيرفر
app.listen(3000, () => {
  console.log("✅ لوحة التحكم تعمل على http://localhost:3000");
});